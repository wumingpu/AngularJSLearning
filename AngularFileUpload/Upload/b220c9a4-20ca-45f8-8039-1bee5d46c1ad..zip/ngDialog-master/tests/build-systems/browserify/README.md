This is test of ngDialog under Browserify
